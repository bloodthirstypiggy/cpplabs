#pragma once
#include <windows.h>
#include <gl/gl.h>
#include "library/stb_easy_font.h"
//#include "library/irrklang/irrKlang.h"
#define STB_IMAGE_IMPLEMENTATION
#include "library/stb_image.h"
#pragma comment(lib, "opengl32.lib")